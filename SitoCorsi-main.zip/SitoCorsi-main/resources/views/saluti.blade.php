<html>
<head>
        <title></title>
</head>
<body>
    <h1> Ciao, {{$name}}</h1>
</body>
</html>
