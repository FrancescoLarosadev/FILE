<html lang="en">
<head>
    <title>{{$Title}} | {{$subtitle}}</title>
</head>
<body style="background: red">
<h1>Ciao, {{$name}}</h1>
<h1> Totale = {{$pippo}}</h1>
</body>
</html>
