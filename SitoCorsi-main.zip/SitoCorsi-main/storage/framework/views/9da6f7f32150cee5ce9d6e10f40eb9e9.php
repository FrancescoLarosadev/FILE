<html lang="en">
<head>
    <title><?php echo e($Title); ?> | <?php echo e($subtitle); ?></title>
</head>
<body style="background: red">
<h1>Ciao, <?php echo e($name); ?></h1>
<h1> Totale = <?php echo e($pippo); ?></h1>
</body>
</html>
<?php /**PATH C:\code\laravel\example\resources\views/lecturers/index.blade.php ENDPATH**/ ?>