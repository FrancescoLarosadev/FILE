


<html>
<head>
    <title><?php echo e($name); ?></title>
    <style>
        body {
            background-color: #86a7a7;

        }
    </style>
</head>
<body>
<h1 style="color: black ">
    <?php echo e($slot); ?>

</h1>

</body>
</html>
<?php /**PATH C:\code\laravel\example\resources\views/components/live-musa-template.blade.php ENDPATH**/ ?>