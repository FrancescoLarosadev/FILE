<?php

function getContacts(mysqli $mysqli, array $params){



}