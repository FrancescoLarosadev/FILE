<?php

// DB SETTINGS
const DB_HOST = 'localhost';
const DB_PORT = 3306;
const DB_NAME = 'e_commerce_db';
const DB_USER = 'root';
const DB_PASS = '2802';

