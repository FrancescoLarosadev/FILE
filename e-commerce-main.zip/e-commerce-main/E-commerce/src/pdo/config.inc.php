<?php

const HOST = "localhost";
const PORT  = 3306;
const DB = "e_commerce_db";
const USER = "root";
const PASSWORD = "2802";


