
<?php
require_once "pdo/config.inc.php";
require_once "pdo/Helper.inc.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title><?=getPageTitle()?></title>
</head>
<body>
404
</body>
</html>