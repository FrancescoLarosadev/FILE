<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width§=device-width", initial-scale=1">
    <title>Pre e-commerce</title>
    <link href="
https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css
" rel="stylesheet">
    <style>
        div.container{
            margin-top: 120px;
            max-height: 400px;
            max-width: 400px;
        }
    </style>
</head>
<body>
<div class="container">

        <div>

            <div class="mb-3">
                <label form="exampleInputEmail1" class="form-label">Email</label>
                <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Password</label>
                <input type="password" class="form-control" id="exampleInputPassword1">
            </div>
            <div class="col-6">
                <a target="_blank" class="btn btn-primary" href="Registrati.php" style="max-width: 110px">Registrati</a>

            </div>
        </div>
    </form>
</div>
<script src="
https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js
"></script>
</body>
</html>

<?php

//
//<div class="row">
// <button type="submit" class="btn btn-primary" style="max-width:110px"> Submit</button>
//